<?php
$con = mysqli_connect("localhost","root","","hotel_management") or die(mysql_error());

?>