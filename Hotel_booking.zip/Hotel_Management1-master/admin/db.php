<?php
$con = mysqli_connect("localhost","root","","Hotel_management") or die(mysql_error());

?>