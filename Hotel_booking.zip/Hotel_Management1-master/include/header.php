<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="Chi Lin" >
		<title><?php echo SITENAME;?></title>
		<link rel="icon" href="/favicon.png" type="image/png" sizes="16x16">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/blog-home.css" rel="stylesheet">
	</head>
	<body>