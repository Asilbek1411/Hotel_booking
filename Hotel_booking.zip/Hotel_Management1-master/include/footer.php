		
		<footer class="navbar-bottom navbar-inverse" style="color: #bf5506; text-align: center; height: 5vh;">
			<p>Copyright &copy; Sun Of Beach 2020. All Rights Reserved.</p>
		</footer>
		
		