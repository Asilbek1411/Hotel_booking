## Hotel Management System
Efficient online booking system which allows administrators to validate and confirm bookings, with a common database for all branches of the hotel.\
Admin can add rooms, branches as well as edit details of the same, view all bookings, and add another admin.\
Customers can book a room of any category, which in turn will be confirmed by an admin.\
Customers can view their booking, receive an invoice and contact the admins for queries.
